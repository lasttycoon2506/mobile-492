import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:intl/intl.dart';
import 'new_post_screen.dart';
import 'post_details_screen.dart';

class EntryListsScreen extends StatefulWidget {
  static const routeName = '/';

  const EntryListsScreen({Key? key}) : super(key: key);

  @override
  EntryListsScreenState createState() => EntryListsScreenState();
}

class EntryListsScreenState extends State<EntryListsScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Wasteagram'),
        centerTitle: true,
      ),
      body: StreamBuilder(
          stream: FirebaseFirestore.instance
              .collection('posts')
              .orderBy('date', descending: true)
              .snapshots(),
          builder:
              (BuildContext context, AsyncSnapshot<QuerySnapshot> snapshot) {
            if (snapshot.hasData && snapshot.data!.docs.isNotEmpty) {
              return ListView.builder(
                  itemCount: snapshot.data!.docs.length,
                  itemBuilder: (context, index) {
                    var post = snapshot.data!.docs[index];
                    return Padding(
                      padding: const EdgeInsets.all(10),
                      child: Semantics(
                        enabled: true,
                        hint: 'Tap for Details',
                        child: ListTile(
                          title: Text(
                              style: const TextStyle(
                                  fontSize: 30, fontWeight: FontWeight.bold),
                              DateFormat.yMMMd().format(post['date'].toDate())),
                          trailing: Text(post['quantity'].toString(),
                              style: const TextStyle(
                                  color: Color.fromARGB(255, 4, 209, 232),
                                  fontSize: 30,
                                  fontWeight: FontWeight.bold)),
                          onTap: () {
                            Navigator.of(context).push(MaterialPageRoute(
                                builder: (context) =>
                                    PostDetailsScreen(post: post)));
                          },
                        ),
                      ),
                    );
                  });
            } else {
              return const Center(child: CircularProgressIndicator());
            }
          }),
      floatingActionButton: const NewPostButton(),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerFloat,
    );
  }
}

class NewPostButton extends StatelessWidget {
  const NewPostButton({super.key});

  @override
  Widget build(BuildContext context) {
    return Semantics(
      label: 'Select a Photo',
      button: true,
      enabled: true,
      tooltip: 'Select a Photo',
      child: FloatingActionButton(
          child: const Icon(Icons.photo_camera),
          onPressed: () {
            Navigator.pushNamed(context, NewPostScreen.routeName);
          }),
    );
  }
}
