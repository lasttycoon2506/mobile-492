import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:transparent_image/transparent_image.dart';

class PostDetailsScreen extends StatelessWidget {
  static const routeName = 'postDetailsScreen';
  dynamic post;

  PostDetailsScreen({super.key, this.post});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Wasteagram'),
      ),
      body: Center(
          child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(20),
              child: Text(
                  style: const TextStyle(
                      fontSize: 30,
                      color: Colors.purple,
                      fontWeight: FontWeight.bold),
                  DateFormat.yMMMd().format(post['date'].toDate())),
            ),
            FadeInImage.memoryNetwork(
              placeholder: kTransparentImage,
              image: post['imageURL'].toString(),
            ),
            Padding(
              padding: const EdgeInsets.all(40),
              child: Text(
                post['quantity'].toString(),
                style: const TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                    color: Colors.blue),
              ),
            ),
            Text(
                'Location:  (${post['latitude'].toString()} , ${post['longitude'].toString()})')
          ],
        ),
      )),
    );
  }
}
